7_Patient_1573_(LLA_T)_241003-patient-1573_(LT)_20241003_192218_231_Point0001_ChannelBF1-ROI_Seq0005.mp4
Original video, all 285 frames untouched -- build your own pair at
any frame separation (dt) with cv2.VideoCapture and evaluate it with
Metrics/we_dc.py (no ground truth needed; this dataset has none).
